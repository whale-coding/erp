package com.bdqn.sys.controller;


import com.bdqn.sys.utils.DataGridViewResult;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author KazuGin
 * @since 2019-12-24
 */
@RestController
@RequestMapping("/sys/permission")
public class PermissionController {


}

