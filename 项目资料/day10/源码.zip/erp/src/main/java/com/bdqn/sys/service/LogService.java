package com.bdqn.sys.service;

import com.bdqn.sys.entity.Log;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author KazuGin
 * @since 2019-12-24
 */
public interface LogService extends IService<Log> {

}
