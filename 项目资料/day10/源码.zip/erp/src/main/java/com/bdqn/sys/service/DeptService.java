package com.bdqn.sys.service;

import com.bdqn.sys.entity.Dept;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author KazuGin
 * @since 2019-12-27
 */
public interface DeptService extends IService<Dept> {

}
