package com.bdqn.sys.service;

import com.bdqn.sys.entity.Notice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author KazuGin
 * @since 2019-12-26
 */
public interface NoticeService extends IService<Notice> {

}
