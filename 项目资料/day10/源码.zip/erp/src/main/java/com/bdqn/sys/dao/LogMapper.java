package com.bdqn.sys.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bdqn.sys.entity.Log;

public interface LogMapper extends BaseMapper<Log> {
}
